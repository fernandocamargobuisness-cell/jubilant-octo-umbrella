package com.stableaction.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

class StabilizedPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val lock = ReentrantLock()
    private var latestBitmap: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = RectF()
    private val dstRect = RectF()

    fun enqueue(bitmap: Bitmap) {
        lock.withLock {
            latestBitmap?.recycle()
            latestBitmap = bitmap
        }
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = lock.withLock { latestBitmap } ?: return

        canvas.drawColor(android.graphics.Color.BLACK)

        val vW = width.toFloat()
        val vH = height.toFloat()
        val bW = bmp.width.toFloat()
        val bH = bmp.height.toFloat()

        val scale = minOf(vW / bW, vH / bH)
        val scaledW = bW * scale
        val scaledH = bH * scale
        val left = (vW - scaledW) / 2f
        val top = (vH - scaledH) / 2f

        srcRect.set(0f, 0f, bW, bH)
        dstRect.set(left, top, left + scaledW, top + scaledH)
        canvas.drawBitmap(bmp, null, dstRect, paint)
    }
}
