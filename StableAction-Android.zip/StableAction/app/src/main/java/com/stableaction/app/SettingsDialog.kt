package com.stableaction.app

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class SettingsDialog(
    context: Context,
    private val camera: CameraManager,
    private val onApply: () -> Unit
) : Dialog(context) {

    init {
        val dp = context.resources.displayMetrics.density

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1A1A1A"))
            setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt())
        }

        // Title
        root.addView(TextView(context).apply {
            text = "⚙️  Settings"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, (20*dp).toInt())
        })

        // --- CAMERA ---
        root.addView(sectionLabel(context, "📷  Camera", dp))
        val lensGroup = RadioGroup(context).apply { orientation = RadioGroup.VERTICAL }
        CameraManager.LensOption.values().forEachIndexed { i, opt ->
            lensGroup.addView(RadioButton(context).apply {
                text = opt.label
                id = i
                setTextColor(Color.WHITE)
                isChecked = camera.selectedLens == opt
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.YELLOW)
            })
        }
        lensGroup.setOnCheckedChangeListener { _, id ->
            camera.selectedLens = CameraManager.LensOption.values()[id]
        }
        root.addView(lensGroup)

        root.addView(divider(context, dp))

        // --- RESOLUTION ---
        root.addView(sectionLabel(context, "🎬  Resolution", dp))
        val resGroup = RadioGroup(context).apply { orientation = RadioGroup.VERTICAL }
        CameraManager.ResolutionOption.values().forEachIndexed { i, opt ->
            resGroup.addView(RadioButton(context).apply {
                text = opt.label
                id = i + 10
                setTextColor(Color.WHITE)
                isChecked = camera.selectedResolution == opt
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.YELLOW)
            })
        }
        resGroup.setOnCheckedChangeListener { _, id ->
            camera.selectedResolution = CameraManager.ResolutionOption.values()[id - 10]
        }
        root.addView(resGroup)

        root.addView(divider(context, dp))

        // Apply button
        root.addView(TextView(context).apply {
            text = "Apply"
            textSize = 15f
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.YELLOW)
            gravity = Gravity.CENTER
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (12*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (16*dp).toInt() }
            setOnClickListener { onApply(); dismiss() }
        })

        setContentView(root)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setLayout((300*dp).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        window?.setGravity(Gravity.CENTER)
    }

    private fun sectionLabel(ctx: Context, text: String, dp: Float) = TextView(ctx).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.parseColor("#AAAAAA"))
        setPadding(0, 0, 0, (8*dp).toInt())
    }

    private fun divider(ctx: Context, dp: Float) = View(ctx).apply {
        setBackgroundColor(Color.parseColor("#333333"))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, (1*dp).toInt()
        ).apply { topMargin = (16*dp).toInt(); bottomMargin = (16*dp).toInt() }
    }
}
