package com.stableaction.app

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class HorizonOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val cropFraction = 3.0 / 5.0 * 0.90
    private val cropAspectW = 3.0
    private val cropAspectH = 4.0

    private var roll: Double = 0.0
    private var offsetX: Double = 0.0
    private var offsetY: Double = 0.0

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(10, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb((255 * 0.6).toInt(), 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
    }

    fun updateMotion(roll: Double, offsetX: Double, offsetY: Double) {
        this.roll = roll
        this.offsetX = offsetX
        this.offsetY = offsetY
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cW = width.toFloat()
        val cH = height.toFloat()
        val shorter = min(cW, cH)
        val rectW = shorter * cropFraction.toFloat()
        val rectH = rectW * (cropAspectH / cropAspectW).toFloat()

        val marginX = (cW - rectW) / 2f
        val marginY = (cH - rectH) / 2f
        val shiftX = (offsetX * marginX * 0.9).toFloat()
        val shiftY = (offsetY * marginY * 0.9).toFloat()

        val cx = cW / 2f + shiftX
        val cy = cH / 2f - shiftY  // negate Y (like iOS)

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(Math.toDegrees(-roll).toFloat())

        val left = -rectW / 2f
        val top = -rectH / 2f
        val right = rectW / 2f
        val bottom = rectH / 2f

        // Fill
        canvas.drawRect(left, top, right, bottom, fillPaint)
        // Border
        canvas.drawRect(left, top, right, bottom, borderPaint)
        // Corner brackets
        drawCornerBrackets(canvas, left, top, right, bottom)

        canvas.restore()
    }

    private fun drawCornerBrackets(canvas: Canvas, l: Float, t: Float, r: Float, b: Float) {
        val arm = 36f
        val path = Path()

        // Top-left
        path.moveTo(l, t + arm); path.lineTo(l, t); path.lineTo(l + arm, t)
        // Top-right
        path.moveTo(r - arm, t); path.lineTo(r, t); path.lineTo(r, t + arm)
        // Bottom-right
        path.moveTo(r, b - arm); path.lineTo(r, b); path.lineTo(r - arm, b)
        // Bottom-left
        path.moveTo(l + arm, b); path.lineTo(l, b); path.lineTo(l, b - arm)

        canvas.drawPath(path, cornerPaint)
    }
}
