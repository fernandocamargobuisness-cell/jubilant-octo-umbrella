package com.stableaction.app

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class HorizonOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var roll = 0.0
    private var offX = 0.0
    private var offY = 0.0

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(10, 255, 255, 255); style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(153, 255, 255, 255); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
    }

    fun updateMotion(roll: Double, offX: Double, offY: Double) {
        this.roll = roll; this.offX = offX; this.offY = offY
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val shorter = min(width, height).toFloat()
        val rW = shorter * (3f / 5f) * 0.90f
        val rH = rW * 4f / 3f
        val shiftX = (offX * (width  - rW) / 2f * 0.9f).toFloat()
        val shiftY = (offY * (height - rH) / 2f * 0.9f).toFloat()

        canvas.save()
        canvas.translate(width / 2f + shiftX, height / 2f - shiftY)
        canvas.rotate(Math.toDegrees(-roll).toFloat())

        val l = -rW / 2f; val t = -rH / 2f; val r = rW / 2f; val b = rH / 2f
        canvas.drawRect(l, t, r, b, fillPaint)
        canvas.drawRect(l, t, r, b, borderPaint)

        val arm = 36f
        val path = Path().apply {
            moveTo(l, t + arm); lineTo(l, t); lineTo(l + arm, t)
            moveTo(r - arm, t); lineTo(r, t); lineTo(r, t + arm)
            moveTo(r, b - arm); lineTo(r, b); lineTo(r - arm, b)
            moveTo(l + arm, b); lineTo(l, b); lineTo(l, b - arm)
        }
        canvas.drawPath(path, cornerPaint)
        canvas.restore()
    }
}
