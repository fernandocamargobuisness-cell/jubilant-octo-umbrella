package com.stableaction.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator

class ActionToggleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var isOn: Boolean = false
        private set

    var onToggle: ((Boolean) -> Unit)? = null

    private val pillHeight = context.resources.displayMetrics.density * 44f
    private val pad = context.resources.displayMetrics.density * 6f

    // Animated knob position: 0.0 = left (Normal), 1.0 = right (Action)
    private var knobPosition = 0f
    private var animator: ValueAnimator? = null

    // Paints
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.resources.displayMetrics.density * 1f
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        setShadowLayer(
            context.resources.displayMetrics.density * 4f,
            0f,
            context.resources.displayMetrics.density * 2f,
            Color.argb(46, 0, 0, 0)
        )
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = context.resources.displayMetrics.density * 13f
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val iconTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = context.resources.displayMetrics.density * 11f
        textAlign = Paint.Align.CENTER
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        setMeasuredDimension(measuredWidth, pillHeight.toInt())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f

        // Background pill
        val bgRect = RectF(0f, 0f, w, h)
        canvas.drawRoundRect(bgRect, r, r, bgPaint)

        // Border gradient
        borderPaint.shader = LinearGradient(
            0f, 0f, w, h,
            Color.argb(140, 255, 255, 255),
            Color.argb(26, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(bgRect, r, r, borderPaint)

        // Sliding knob
        val halfW = w / 2f
        val knobLeft = pad / 2f + knobPosition * halfW
        val knobRight = knobLeft + halfW - pad
        val knobRect = RectF(knobLeft, pad, knobRight, h - pad)
        val knobR = (h - pad * 2) / 2f
        canvas.drawRoundRect(knobRect, knobR, knobR, knobPaint)

        // Left label: Normal
        val leftActive = !isOn
        textPaint.color = if (leftActive) Color.BLACK else Color.WHITE
        canvas.drawText("Normal", halfW / 2f, h / 2f + textPaint.textSize / 3f, textPaint)

        // Right label: Action
        val rightActive = isOn
        textPaint.color = if (rightActive) Color.BLACK else Color.WHITE
        canvas.drawText("Action", halfW + halfW / 2f, h / 2f + textPaint.textSize / 3f, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_UP -> {
                val newState = event.x > width / 2f
                if (newState != isOn) {
                    setOn(newState, animate = true)
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onToggle?.invoke(isOn)
                }
                return true
            }
        }
        return true
    }

    fun setOn(on: Boolean, animate: Boolean = false) {
        isOn = on
        val target = if (on) 1f else 0f
        if (animate) {
            animator?.cancel()
            animator = ValueAnimator.ofFloat(knobPosition, target).apply {
                duration = 280
                interpolator = DecelerateInterpolator(1.5f)
                addUpdateListener {
                    knobPosition = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            knobPosition = target
            invalidate()
        }
    }
}
