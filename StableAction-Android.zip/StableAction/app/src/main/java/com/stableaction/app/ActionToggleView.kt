package com.stableaction.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator

class ActionToggleView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var isOn = false; private set
    var onToggle: ((Boolean) -> Unit)? = null

    private val dp = context.resources.displayMetrics.density
    private val pad = 6f * dp
    private var knob = 0f
    private var anim: ValueAnimator? = null

    private val bgPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60,255,255,255) }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE
        setShadowLayer(4*dp,0f,2*dp, Color.argb(46,0,0,0)) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 13*dp; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(
        resolveSize((200*dp).toInt(), w), (44*dp).toInt())

    override fun onDraw(canvas: Canvas) {
        val W = width.toFloat(); val H = height.toFloat(); val r = H/2f
        canvas.drawRoundRect(RectF(0f,0f,W,H), r, r, bgPaint)

        val half = W/2f
        val kl = pad/2f + knob*half
        val kr = kl + half - pad
        val kr2 = (H - pad*2)/2f
        canvas.drawRoundRect(RectF(kl, pad, kr, H-pad), kr2, kr2, knobPaint)

        textPaint.color = if (!isOn) Color.BLACK else Color.WHITE
        canvas.drawText("Normal", half/2f, H/2f + textPaint.textSize/3f, textPaint)
        textPaint.color = if (isOn) Color.BLACK else Color.WHITE
        canvas.drawText("Action", half + half/2f, H/2f + textPaint.textSize/3f, textPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val new = e.x > width/2f
            if (new != isOn) { isOn = new; animate(); performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onToggle?.invoke(isOn) }
        }
        return true
    }

    private fun animate() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(knob, if (isOn) 1f else 0f).apply {
            duration = 280; interpolator = DecelerateInterpolator(1.5f)
            addUpdateListener { knob = it.animatedValue as Float; invalidate() }
            start()
        }
    }
}
