package com.stableaction.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class RecordButton @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var isRecording = false
        set(v) { field = v; animateTo(if (v) 1f else 0f) }

    var onClick: (() -> Unit)? = null

    private val dp = context.resources.displayMetrics.density
    private var progress = 0f

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 5*dp }
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED; style = Paint.Style.FILL }

    override fun onMeasure(w: Int, h: Int) {
        val s = (78*dp).toInt(); setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width/2f; val cy = height/2f
        canvas.drawCircle(cx, cy, width/2f - 5*dp, ringPaint)
        val s = 30*dp
        val corner = s/2f*(1-progress) + 6*dp*progress
        canvas.drawRoundRect(RectF(cx-s/2f,cy-s/2f,cx+s/2f,cy+s/2f), corner, corner, innerPaint)
    }

    private fun animateTo(target: Float) {
        ValueAnimator.ofFloat(progress, target).apply {
            duration = 250
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    init { setOnClickListener { onClick?.invoke() } }
}
