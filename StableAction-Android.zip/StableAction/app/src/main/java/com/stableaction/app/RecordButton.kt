package com.stableaction.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

class RecordButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var isRecording: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                animateState()
            }
        }

    var onClick: (() -> Unit)? = null

    private val density = context.resources.displayMetrics.density

    // Animated: 0=circle, 1=square
    private var shapeProgress = 0f
    private var animator: ValueAnimator? = null

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = density * 5f
    }
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.FILL
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = (density * 78f).toInt()
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val ringR = width / 2f - density * 5f

        // Outer white ring
        canvas.drawCircle(cx, cy, ringR, ringPaint)

        // Inner shape: interpolates from circle (r=30dp) to rounded square (side=30dp)
        val innerSize = density * 30f
        val cornerRadius = innerSize / 2f * (1f - shapeProgress) + density * 6f * shapeProgress
        val left = cx - innerSize / 2f
        val top = cy - innerSize / 2f
        val right = cx + innerSize / 2f
        val bottom = cy + innerSize / 2f
        val rect = RectF(left, top, right, bottom)
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, innerPaint)
    }

    private fun animateState() {
        animator?.cancel()
        val target = if (isRecording) 1f else 0f
        animator = ValueAnimator.ofFloat(shapeProgress, target).apply {
            duration = 250
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                shapeProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun performClick(): Boolean {
        super.performClick()
        onClick?.invoke()
        return true
    }

    init {
        setOnClickListener { onClick?.invoke() }
    }
}
