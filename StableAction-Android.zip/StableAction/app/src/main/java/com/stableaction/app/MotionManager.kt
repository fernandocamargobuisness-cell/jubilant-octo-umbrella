package com.stableaction.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.abs
import kotlin.math.atan2

class MotionManager(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val gravity = FloatArray(3) { 0f }

    // Published values (main thread)
    @Volatile var roll: Double = 0.0
    @Volatile var offsetX: Double = 0.0
    @Volatile var offsetY: Double = 0.0

    // Thread-safe snapshot
    private val snapshotLock = ReentrantLock()
    private var snapRoll: Double = 0.0
    private var snapOffsetX: Double = 0.0
    private var snapOffsetY: Double = 0.0

    // Tuning constants (same as iOS app)
    private val velocityDecay = 0.82
    private val positionDecay = 0.992
    private val sensitivity = 0.035
    private val accelDeadZone = 0.02
    private val dt = 1.0 / 120.0

    private var velX = 0.0
    private var velY = 0.0
    private var lastTimestamp = 0L

    // Callback for UI updates
    var onMotionUpdate: ((roll: Double, offsetX: Double, offsetY: Double) -> Unit)? = null

    fun start() {
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST) }
        gyroscope?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST) }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        velX = 0.0
        velY = 0.0
        snapshotLock.withLock {
            snapRoll = 0.0
            snapOffsetX = 0.0
            snapOffsetY = 0.0
        }
        roll = 0.0
        offsetX = 0.0
        offsetY = 0.0
    }

    fun snapshot(): Triple<Double, Double, Double> {
        return snapshotLock.withLock {
            Triple(snapRoll, snapOffsetX, snapOffsetY)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                // Low-pass filter for gravity
                val alpha = 0.8f
                gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0]
                gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1]
                gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2]

                // Compute roll (equivalent to iOS atan2(gravity.x, -gravity.y))
                val newRoll = atan2(gravity[0].toDouble(), (-gravity[1]).toDouble())

                // Linear acceleration (remove gravity)
                var ax = (event.values[0] - gravity[0]).toDouble() / SensorManager.GRAVITY_EARTH
                var ay = (event.values[1] - gravity[1]).toDouble() / SensorManager.GRAVITY_EARTH

                // Dead zone
                if (abs(ax) < accelDeadZone) ax = 0.0
                if (abs(ay) < accelDeadZone) ay = 0.0

                // Integrate acceleration → velocity → position
                velX = (velX + ax * dt) * velocityDecay
                velY = (velY + ay * dt) * velocityDecay

                var newOffX = (snapOffsetX - velX * sensitivity) * positionDecay
                var newOffY = (snapOffsetY - velY * sensitivity) * positionDecay

                newOffX = newOffX.coerceIn(-1.0, 1.0)
                newOffY = newOffY.coerceIn(-1.0, 1.0)

                snapshotLock.withLock {
                    snapRoll = newRoll
                    snapOffsetX = newOffX
                    snapOffsetY = newOffY
                }

                roll = newRoll
                offsetX = newOffX
                offsetY = newOffY

                onMotionUpdate?.invoke(newRoll, newOffX, newOffY)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
