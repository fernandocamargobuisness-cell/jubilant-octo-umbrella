package com.stableaction.app

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.abs
import kotlin.math.atan2

class MotionManager(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val lock = ReentrantLock()
    private var snapRoll = 0.0
    private var snapOffsetX = 0.0
    private var snapOffsetY = 0.0

    private val gravity = FloatArray(3)
    private var velX = 0.0
    private var velY = 0.0

    private val velocityDecay = 0.82
    private val positionDecay = 0.992
    private val sensitivity = 0.035
    private val accelDeadZone = 0.02
    private val dt = 1.0 / 60.0

    var onMotionUpdate: ((Double, Double, Double) -> Unit)? = null

    fun start() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        lock.withLock { snapRoll = 0.0; snapOffsetX = 0.0; snapOffsetY = 0.0 }
        velX = 0.0; velY = 0.0
    }

    fun snapshot() = lock.withLock { Triple(snapRoll, snapOffsetX, snapOffsetY) }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        val alpha = 0.8f
        gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0]
        gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1]
        gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2]

        val newRoll = atan2(gravity[0].toDouble(), (-gravity[1]).toDouble())

        var ax = (event.values[0] - gravity[0]).toDouble() / SensorManager.GRAVITY_EARTH
        var ay = (event.values[1] - gravity[1]).toDouble() / SensorManager.GRAVITY_EARTH
        if (abs(ax) < accelDeadZone) ax = 0.0
        if (abs(ay) < accelDeadZone) ay = 0.0

        velX = (velX + ax * dt) * velocityDecay
        velY = (velY + ay * dt) * velocityDecay

        val newOffX = ((snapOffsetX - velX * sensitivity) * positionDecay).coerceIn(-1.0, 1.0)
        val newOffY = ((snapOffsetY - velY * sensitivity) * positionDecay).coerceIn(-1.0, 1.0)

        lock.withLock { snapRoll = newRoll; snapOffsetX = newOffX; snapOffsetY = newOffY }
        onMotionUpdate?.invoke(newRoll, newOffX, newOffY)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
