package com.stableaction.app

import android.animation.*
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class FocusView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = context.resources.displayMetrics.density
    private val size = density * 76f
    private val cornerLen = density * 14f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        style = Paint.Style.STROKE
        strokeWidth = density * 2f
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb((255 * 0.6).toInt(), 255, 255, 0)
        style = Paint.Style.FILL
    }

    private var focusX = 0f
    private var focusY = 0f
    private var currentScale = 1f
    private var currentAlpha = 0f

    fun showAt(x: Float, y: Float) {
        focusX = x
        focusY = y
        currentScale = 1.4f
        currentAlpha = 1f
        visibility = VISIBLE

        val scaleAnim = ValueAnimator.ofFloat(1.4f, 1.0f).apply {
            duration = 200
            addUpdateListener { currentScale = it.animatedValue as Float; invalidate() }
        }
        val fadeAnim = ValueAnimator.ofFloat(1f, 0f).apply {
            startDelay = 1200
            duration = 300
            addUpdateListener {
                currentAlpha = it.animatedValue as Float
                invalidate()
                if (currentAlpha == 0f) visibility = INVISIBLE
            }
        }
        AnimatorSet().apply {
            playTogether(scaleAnim, fadeAnim)
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        paint.alpha = (currentAlpha * 255).toInt()
        dotPaint.alpha = (currentAlpha * 255 * 0.6f).toInt()

        canvas.save()
        canvas.translate(focusX, focusY)
        canvas.scale(currentScale, currentScale)

        val half = size / 2f
        val path = Path()
        // TL
        path.moveTo(-half, -half + cornerLen); path.lineTo(-half, -half); path.lineTo(-half + cornerLen, -half)
        // TR
        path.moveTo(half - cornerLen, -half); path.lineTo(half, -half); path.lineTo(half, -half + cornerLen)
        // BR
        path.moveTo(half, half - cornerLen); path.lineTo(half, half); path.lineTo(half - cornerLen, half)
        // BL
        path.moveTo(-half + cornerLen, half); path.lineTo(-half, half); path.lineTo(-half, half - cornerLen)

        canvas.drawPath(path, paint)
        canvas.drawCircle(0f, 0f, density * 2.5f, dotPaint)
        canvas.restore()
    }
}
