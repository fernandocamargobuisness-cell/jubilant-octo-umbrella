package com.stableaction.app

import android.animation.*
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class FocusView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val dp = context.resources.displayMetrics.density
    private val size = 76*dp; private val arm = 14*dp
    private var fx = 0f; private var fy = 0f
    private var scale = 1f; private var alpha = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE
        strokeWidth = 2*dp; strokeCap = Paint.Cap.ROUND }

    fun showAt(x: Float, y: Float) {
        fx = x; fy = y; scale = 1.4f; alpha = 1f; visibility = VISIBLE
        AnimatorSet().apply {
            playTogether(
                ValueAnimator.ofFloat(1.4f,1f).apply { duration=200
                    addUpdateListener { scale=it.animatedValue as Float; invalidate() } },
                ValueAnimator.ofFloat(1f,0f).apply { startDelay=1200; duration=300
                    addUpdateListener { alpha=it.animatedValue as Float; invalidate()
                        if(alpha==0f) visibility=INVISIBLE } }
            ); start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        paint.alpha = (alpha*255).toInt()
        canvas.save()
        canvas.translate(fx, fy); canvas.scale(scale, scale)
        val h = size/2f
        canvas.drawPath(Path().apply {
            moveTo(-h,-h+arm); lineTo(-h,-h); lineTo(-h+arm,-h)
            moveTo(h-arm,-h);  lineTo(h,-h);  lineTo(h,-h+arm)
            moveTo(h,h-arm);   lineTo(h,h);   lineTo(h-arm,h)
            moveTo(-h+arm,h);  lineTo(-h,h);  lineTo(-h,h-arm)
        }, paint)
        canvas.restore()
    }
}
