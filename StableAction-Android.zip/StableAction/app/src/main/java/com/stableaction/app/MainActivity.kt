package com.stableaction.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val TAG = "StableAction"

    private lateinit var previewView: PreviewView
    private lateinit var stabilizedView: StabilizedPreviewView
    private lateinit var horizonOverlay: HorizonOverlayView
    private lateinit var focusView: FocusView
    private lateinit var recordButton: RecordButton
    private lateinit var actionToggle: ActionToggleView
    private lateinit var thumbnailView: ImageView
    private lateinit var recIndicator: View
    private lateinit var permissionOverlay: View

    private var camera: CameraManager? = null
    private var motion: MotionManager? = null
    private var blinkRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        previewView     = findViewById(R.id.previewView)
        stabilizedView  = findViewById(R.id.stabilizedView)
        horizonOverlay  = findViewById(R.id.horizonOverlay)
        focusView       = findViewById(R.id.focusView)
        recordButton    = findViewById(R.id.recordButton)
        actionToggle    = findViewById(R.id.actionToggle)
        thumbnailView   = findViewById(R.id.thumbnailView)
        recIndicator    = findViewById(R.id.recIndicator)
        permissionOverlay = findViewById(R.id.permissionOverlay)

        if (hasPermissions()) startApp()
        else ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 10)
    }

    private fun hasPermissions() = listOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO
    ).all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    private fun startApp() {
        Log.d(TAG, "startApp")
        permissionOverlay.visibility = View.GONE

        motion = MotionManager(this)
        camera = CameraManager(this, this)

        camera!!.motionSnapshotProvider = { motion!!.snapshot() }

        camera!!.onFrameProcessed = { bmp ->
            stabilizedView.enqueue(bmp)
        }

        camera!!.onRecordingStateChanged = { rec ->
            runOnUiThread {
                recordButton.isRecording = rec
                if (rec) {
                    recIndicator.visibility = View.VISIBLE
                    startBlink()
                } else {
                    stopBlink()
                    recIndicator.visibility = View.GONE
                }
            }
        }

        camera!!.onLastVideoChanged = { uri ->
            uri ?: return@onLastVideoChanged
            runOnUiThread { loadThumbnail(uri) }
        }

        camera!!.startCamera(previewView)
        motion!!.start()

        motion!!.onMotionUpdate = { roll, x, y ->
            if (actionToggle.isOn) runOnUiThread { horizonOverlay.updateMotion(roll, x, y) }
        }

        recordButton.onClick = { camera!!.toggleRecording() }

        actionToggle.onToggle = { on ->
            previewView.visibility    = if (on) View.INVISIBLE else View.VISIBLE
            stabilizedView.visibility = if (on) View.VISIBLE   else View.INVISIBLE
            horizonOverlay.visibility = if (on) View.VISIBLE   else View.INVISIBLE
            camera!!.setActionMode(on, previewView)
        }

        previewView.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP) focusView.showAt(ev.x, ev.y)
            true
        }

        thumbnailView.setOnClickListener {
            camera?.lastVideoUri?.let { uri ->
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "video/mp4")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }
        }

        findViewById<View>(R.id.coffeeBtn).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://buymeacoffee.com/rudrashah")))
        }
    }

    private fun startBlink() {
        blinkRunnable = object : Runnable {
            var show = true
            override fun run() {
                recIndicator.alpha = if (show) 1f else 0.25f
                show = !show
                recIndicator.postDelayed(this, 700)
            }
        }.also { recIndicator.post(it) }
    }

    private fun stopBlink() {
        blinkRunnable?.let { recIndicator.removeCallbacks(it) }
        blinkRunnable = null
    }

    private fun loadThumbnail(uri: Uri) {
        Thread {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                val bmp = r.getFrameAtTime(100_000)
                r.release()
                if (bmp != null) runOnUiThread { thumbnailView.setImageBitmap(bmp) }
            } catch (e: Exception) { Log.e(TAG, "thumb error", e) }
        }.start()
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == 10) {
            if (hasPermissions()) startApp()
            else permissionOverlay.visibility = View.VISIBLE
        }
    }

    override fun onResume()  { super.onResume();  motion?.start() }
    override fun onPause()   { super.onPause();   motion?.stop()  }
    override fun onDestroy() { super.onDestroy(); camera?.shutdown(); motion?.stop() }
}
