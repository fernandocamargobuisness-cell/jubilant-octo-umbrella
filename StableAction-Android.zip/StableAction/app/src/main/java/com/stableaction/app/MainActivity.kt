package com.stableaction.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var cameraManager: CameraManager
    private lateinit var motionManager: MotionManager

    private lateinit var previewView: PreviewView
    private lateinit var stabilizedView: StabilizedPreviewView
    private lateinit var horizonOverlay: HorizonOverlayView
    private lateinit var focusView: FocusView
    private lateinit var recordButton: RecordButton
    private lateinit var actionToggle: ActionToggleView
    private lateinit var thumbnailView: ImageView
    private lateinit var recIndicator: View
    private lateinit var recText: TextView
    private lateinit var permissionOverlay: View

    private val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO
    )
    private val REQUEST_CODE_PERMISSIONS = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on while recording
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_main)
        bindViews()

        if (allPermissionsGranted()) {
            startApp()
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }
    }

    private fun bindViews() {
        previewView = findViewById(R.id.previewView)
        stabilizedView = findViewById(R.id.stabilizedView)
        horizonOverlay = findViewById(R.id.horizonOverlay)
        focusView = findViewById(R.id.focusView)
        recordButton = findViewById(R.id.recordButton)
        actionToggle = findViewById(R.id.actionToggle)
        thumbnailView = findViewById(R.id.thumbnailView)
        recIndicator = findViewById(R.id.recIndicator)
        recText = findViewById(R.id.recText)
        permissionOverlay = findViewById(R.id.permissionOverlay)
    }

    private fun startApp() {
        permissionOverlay.visibility = View.GONE

        motionManager = MotionManager(this)
        cameraManager = CameraManager(this, this)

        cameraManager.motionSnapshotProvider = { motionManager.snapshot() }

        // Camera frame → stabilized preview
        cameraManager.onFrameProcessed = { bitmap ->
            stabilizedView.enqueue(bitmap)
        }

        // Recording state
        cameraManager.onRecordingStateChanged = { recording ->
            runOnUiThread {
                recordButton.isRecording = recording
                recIndicator.visibility = if (recording) View.VISIBLE else View.GONE
                if (recording) startRecBlink() else stopRecBlink()
            }
        }

        // Last video thumbnail
        cameraManager.onLastVideoChanged = { uri ->
            runOnUiThread { updateThumbnail(uri) }
        }

        // Start camera
        cameraManager.startCamera(previewView)
        motionManager.start()

        // Motion → horizon overlay
        motionManager.onMotionUpdate = { roll, offsetX, offsetY ->
            runOnUiThread {
                if (actionToggle.isOn) {
                    horizonOverlay.updateMotion(roll, offsetX, offsetY)
                }
            }
        }

        // Record button
        recordButton.onClick = { cameraManager.toggleRecording() }

        // Action mode toggle
        actionToggle.onToggle = { isOn ->
            previewView.visibility = if (isOn) View.INVISIBLE else View.VISIBLE
            stabilizedView.visibility = if (isOn) View.VISIBLE else View.INVISIBLE
            horizonOverlay.visibility = if (isOn) View.VISIBLE else View.INVISIBLE
            cameraManager.setActionMode(isOn, previewView)
        }

        // Tap to focus (normal mode)
        previewView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                focusView.showAt(event.x, event.y)
                val point = previewView.meteringPointFactory.createPoint(event.x, event.y)
                // CameraX handles focus internally via PreviewView
            }
            true
        }

        // Thumbnail tap → open video
        thumbnailView.setOnClickListener {
            cameraManager.lastVideoUri?.let { uri ->
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "video/mp4")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
            }
        }

        // "Buy me a coffee" button
        findViewById<View>(R.id.coffeeBtn).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://buymeacoffee.com/rudrashah")))
        }
    }

    private var blinkRunnable: Runnable? = null
    private fun startRecBlink() {
        blinkRunnable = object : Runnable {
            var visible = true
            override fun run() {
                recIndicator.alpha = if (visible) 1f else 0.2f
                visible = !visible
                recIndicator.postDelayed(this, 700)
            }
        }
        recIndicator.post(blinkRunnable!!)
    }
    private fun stopRecBlink() {
        blinkRunnable?.let { recIndicator.removeCallbacks(it) }
        blinkRunnable = null
    }

    private fun updateThumbnail(uri: Uri?) {
        if (uri == null) {
            thumbnailView.setImageResource(R.drawable.ic_video_placeholder)
            return
        }
        Thread {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                val thumb = retriever.getFrameAtTime(100_000L) // 0.1s in microseconds
                runOnUiThread { thumbnailView.setImageBitmap(thumb) }
            } catch (e: Exception) {
                runOnUiThread { thumbnailView.setImageResource(R.drawable.ic_video_placeholder) }
            } finally {
                retriever.release()
            }
        }.start()
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results)
        if (code == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startApp()
            } else {
                permissionOverlay.visibility = View.VISIBLE
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onResume() {
        super.onResume()
        if (::motionManager.isInitialized) motionManager.start()
    }

    override fun onPause() {
        super.onPause()
        if (::motionManager.isInitialized) motionManager.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::cameraManager.isInitialized) cameraManager.shutdown()
        if (::motionManager.isInitialized) motionManager.stop()
    }
}
