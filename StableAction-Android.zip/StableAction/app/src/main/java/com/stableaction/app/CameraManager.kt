package com.stableaction.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class CameraManager(private val context: Context, private val owner: LifecycleOwner) {

    enum class LensOption(val label: String, val selector: CameraSelector) {
        WIDE("1x Wide", CameraSelector.DEFAULT_BACK_CAMERA),
        ULTRAWIDE("0.6x Ultrawide", CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK).build()),
        FRONT("Front", CameraSelector.DEFAULT_FRONT_CAMERA)
    }

    enum class ResolutionOption(val label: String, val quality: Quality) {
        HD("HD 720p", Quality.HD),
        FHD("Full HD 1080p", Quality.FHD),
        UHD("4K", Quality.UHD)
    }

    @Volatile var isRecording = false; private set
    @Volatile var actionModeEnabled = false
    @Volatile var lastVideoUri: Uri? = null
    var selectedLens = LensOption.WIDE
    var selectedResolution = ResolutionOption.FHD

    var onRecordingStateChanged: ((Boolean) -> Unit)? = null
    var onLastVideoChanged: ((Uri?) -> Unit)? = null
    var onFrameProcessed: ((Bitmap) -> Unit)? = null
    var motionSnapshotProvider: () -> Triple<Double, Double, Double> = { Triple(0.0, 0.0, 0.0) }

    private var provider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private val executor = Executors.newSingleThreadExecutor()

    private var smoothRoll = 0.0
    private var smoothX = 0.0
    private var smoothY = 0.0

    fun startCamera(previewView: PreviewView) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                provider = future.get()
                bind(previewView)
            } catch (e: Exception) {
                Log.e("CameraManager", "Provider init failed", e)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun bind(previewView: PreviewView) {
        val prov = provider ?: return
        try {
            prov.unbindAll()

            // In action mode, prefer ultrawide if available
            val cameraSelector = if (actionModeEnabled) {
                getBestUltrawideSelector() ?: selectedLens.selector
            } else {
                selectedLens.selector
            }

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        selectedResolution.quality,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)
                    )
                ).build()
            videoCapture = VideoCapture.withOutput(recorder)

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build().also {
                    it.setAnalyzer(executor) { proxy -> processFrame(proxy) }
                }

            prov.bindToLifecycle(owner, cameraSelector, preview, videoCapture, analysis)
        } catch (e: Exception) {
            Log.e("CameraManager", "Bind failed: ${e.message}", e)
            // Fallback to back camera
            try {
                provider?.unbindAll()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.HD)).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider?.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture)
            } catch (e2: Exception) {
                Log.e("CameraManager", "Fallback also failed", e2)
            }
        }
    }

    private fun getBestUltrawideSelector(): CameraSelector? {
        return try {
            val prov = provider ?: return null
            // Try ultrawide by checking available cameras zoom ratio
            val selector = CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .addCameraFilter { cameras ->
                    val ultrawide = cameras.filter { cam ->
                        try {
                            val zoomState = cam.zoomState.value
                            zoomState != null && zoomState.minZoomRatio < 0.8f
                        } catch (e: Exception) { false }
                    }
                    if (ultrawide.isNotEmpty()) ultrawide else cameras
                }.build()
            if (prov.hasCamera(selector)) selector else null
        } catch (e: Exception) { null }
    }

    private fun processFrame(proxy: ImageProxy) {
        try {
            if (!actionModeEnabled) { proxy.close(); return }

            val (roll, offX, offY) = motionSnapshotProvider()
            smoothRoll += 0.25 * (roll - smoothRoll)
            smoothX   += 0.10 * (offX - smoothX)
            smoothY   += 0.10 * (offY - smoothY)

            val plane = proxy.planes[0]
            val buf = plane.buffer.also { it.rewind() }
            val rowPad = plane.rowStride - plane.pixelStride * proxy.width
            val bmp = Bitmap.createBitmap(
                proxy.width + rowPad / plane.pixelStride,
                proxy.height, Bitmap.Config.ARGB_8888
            )
            bmp.copyPixelsFromBuffer(buf)

            val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                Matrix().apply { postRotate(90f) }, false)
            bmp.recycle()

            val angleDeg = Math.toDegrees(-smoothRoll).toFloat()
            val stab = Bitmap.createBitmap(rot, 0, 0, rot.width, rot.height,
                Matrix().apply { postRotate(angleDeg, rot.width / 2f, rot.height / 2f) }, false)
            rot.recycle()

            val shorter = min(stab.width, stab.height).toFloat()
            val cropW = (shorter * (3.0 / 5.0) * 0.90).toInt().and(-2)
            val cropH = (cropW * 4.0 / 3.0).toInt().and(-2)

            val marginX = ((stab.width  - cropW) / 2f).coerceAtLeast(0f)
            val marginY = ((stab.height - cropH) / 2f).coerceAtLeast(0f)

            val angleR = (-smoothRoll).toFloat()
            val cosA = cos(angleR.toDouble()).toFloat()
            val sinA = sin(angleR.toDouble()).toFloat()
            val shiftX = (smoothX * cosA - smoothY * sinA).toFloat() * marginX * 0.9f
            val shiftY = (smoothX * sinA + smoothY * cosA).toFloat() * marginY * 0.9f

            val cx = ((stab.width  - cropW) / 2f + shiftX).coerceIn(0f, (stab.width  - cropW).toFloat())
            val cy = ((stab.height - cropH) / 2f + shiftY).coerceIn(0f, (stab.height - cropH).toFloat())

            if (cropW > 0 && cropH > 0 &&
                cx.toInt() + cropW <= stab.width &&
                cy.toInt() + cropH <= stab.height) {
                val cropped = Bitmap.createBitmap(stab, cx.toInt(), cy.toInt(), cropW, cropH)
                onFrameProcessed?.invoke(cropped)
            }
            stab.recycle()
        } catch (e: Exception) {
            Log.e("CameraManager", "Frame error", e)
        } finally {
            proxy.close()
        }
    }

    @SuppressLint("MissingPermission")
    fun toggleRecording() {
        if (isRecording) { recording?.stop(); recording = null; return }
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "SA_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/StableAction")
        }
        val opts = MediaStoreOutputOptions
            .Builder(context.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()

        recording = videoCapture?.output
            ?.prepareRecording(context, opts)
            ?.apply { withAudioEnabled() }
            ?.start(ContextCompat.getMainExecutor(context)) { e ->
                when (e) {
                    is VideoRecordEvent.Start -> { isRecording = true; onRecordingStateChanged?.invoke(true) }
                    is VideoRecordEvent.Finalize -> {
                        isRecording = false; onRecordingStateChanged?.invoke(false)
                        if (!e.hasError()) { lastVideoUri = e.outputResults.outputUri; onLastVideoChanged?.invoke(lastVideoUri) }
                    }
                }
            }
    }

    fun setActionMode(enabled: Boolean, previewView: PreviewView) {
        actionModeEnabled = enabled; bind(previewView)
    }

    fun applySettings(previewView: PreviewView) { bind(previewView) }

    fun shutdown() {
        if (isRecording) recording?.stop()
        executor.shutdown()
    }
}
