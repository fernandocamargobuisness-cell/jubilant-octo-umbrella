package com.stableaction.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.*
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {

    enum class CameraMode { NORMAL, ACTION }

    // State
    @Volatile var isRecording = false
        private set
    @Volatile var actionModeEnabled = false
    @Volatile var lastVideoUri: Uri? = null

    // Callbacks
    var onRecordingStateChanged: ((Boolean) -> Unit)? = null
    var onLastVideoChanged: ((Uri?) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var onFrameProcessed: ((Bitmap) -> Unit)? = null

    // Motion provider
    var motionSnapshotProvider: () -> Triple<Double, Double, Double> = { Triple(0.0, 0.0, 0.0) }

    private var cameraProvider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var imageAnalysis: ImageAnalysis? = null
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    // Stabilization processing
    private val cropFraction = 3.0 / 5.0 * 0.90
    private val cropAspectW = 3.0
    private val cropAspectH = 4.0
    private var smoothedRoll = 0.0
    private var smoothedNormX = 0.0
    private var smoothedNormY = 0.0
    private val rollAlpha = 0.25
    private val translationAlpha = 0.10

    // Processing bitmaps
    private var processingBitmap: Bitmap? = null

    fun startCamera(previewView: PreviewView) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases(previewView)
        }, ContextCompat.getMainExecutor(context))
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun bindCameraUseCases(previewView: PreviewView) {
        val provider = cameraProvider ?: return

        val cameraSelector = if (actionModeEnabled) {
            // Try to use ultrawide for action mode (more crop buffer)
            try {
                val ultrawide = CameraSelector.Builder()
                    .addCameraFilter { cameraInfoList ->
                        cameraInfoList.filter { info ->
                            val c2info = Camera2CameraInfo.from(info)
                            val facing = c2info.getCameraCharacteristic(CameraCharacteristics.LENS_FACING)
                            val focalLengths = c2info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                            facing == CameraCharacteristics.LENS_FACING_BACK &&
                            focalLengths != null && focalLengths.isNotEmpty() &&
                            focalLengths.min() < 2.0f
                        }
                    }.build()
                ultrawide
            } catch (e: Exception) {
                CameraSelector.DEFAULT_BACK_CAMERA
            }
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.HD))
            .build()
        videoCapture = VideoCapture.withOutput(recorder)

        imageAnalysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
            .also { analysis ->
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    if (actionModeEnabled) {
                        processFrame(imageProxy)
                    } else {
                        imageProxy.close()
                    }
                }
            }

        try {
            provider.unbindAll()
            provider.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                videoCapture,
                imageAnalysis
            )
            previewView.visibility = if (actionModeEnabled) android.view.View.INVISIBLE else android.view.View.VISIBLE
        } catch (exc: Exception) {
            Log.e("CameraManager", "Use case binding failed", exc)
            onError?.invoke("Camera binding failed: ${exc.message}")
        }
    }

    private fun processFrame(imageProxy: ImageProxy) {
        val (snapRoll, snapOffsetX, snapOffsetY) = motionSnapshotProvider()

        smoothedRoll += rollAlpha * (snapRoll - smoothedRoll)
        smoothedNormX += translationAlpha * (snapOffsetX - smoothedNormX)
        smoothedNormY += translationAlpha * (snapOffsetY - smoothedNormY)

        val plane = imageProxy.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * imageProxy.width

        val bitmap = Bitmap.createBitmap(
            imageProxy.width + rowPadding / pixelStride,
            imageProxy.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        // Rotate to portrait (sensor is landscape)
        val rotMatrix = Matrix()
        rotMatrix.postRotate(90f)
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, rotMatrix, true)
        bitmap.recycle()

        val pW = rotated.width.toFloat()
        val pH = rotated.height.toFloat()

        // Apply horizon stabilization rotation
        val angle = (-smoothedRoll).toFloat()
        val stabilMatrix = Matrix()
        stabilMatrix.postRotate(Math.toDegrees(angle.toDouble()).toFloat(), pW / 2, pH / 2)
        val stabilized = Bitmap.createBitmap(rotated, 0, 0, rotated.width, rotated.height, stabilMatrix, true)
        rotated.recycle()

        // Crop to 3:4
        val shorter = minOf(pW, pH)
        val cropW = (shorter * cropFraction).toFloat()
        val cropH = (cropW * (cropAspectH / cropAspectW)).toFloat()

        val marginX = maxOf(0f, (stabilized.width - cropW) / 2)
        val marginY = maxOf(0f, (stabilized.height - cropH) / 2)

        val cosA = Math.cos(angle.toDouble()).toFloat()
        val sinA = Math.sin(angle.toDouble()).toFloat()
        val rotNormX = smoothedNormX * cosA - smoothedNormY * sinA
        val rotNormY = smoothedNormX * sinA + smoothedNormY * cosA

        val shiftX = (rotNormX * marginX * 0.9).toFloat()
        val shiftY = (rotNormY * marginY * 0.9).toFloat()

        val cropX = ((stabilized.width - cropW) / 2 + shiftX).coerceIn(0f, (stabilized.width - cropW))
        val cropY = ((stabilized.height - cropH) / 2 + shiftY).coerceIn(0f, (stabilized.height - cropH))

        val cropWInt = cropW.toInt().and(-2) // make even
        val cropHInt = cropH.toInt().and(-2)

        if (cropX >= 0 && cropY >= 0 &&
            cropX + cropWInt <= stabilized.width &&
            cropY + cropHInt <= stabilized.height &&
            cropWInt > 0 && cropHInt > 0) {

            val cropped = Bitmap.createBitmap(stabilized, cropX.toInt(), cropY.toInt(), cropWInt, cropHInt)
            stabilized.recycle()
            onFrameProcessed?.invoke(cropped)
        } else {
            stabilized.recycle()
        }

        imageProxy.close()
    }

    @SuppressLint("MissingPermission")
    fun toggleRecording() {
        if (isRecording) {
            recording?.stop()
            recording = null
        } else {
            val name = SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-SSS", Locale.US).format(System.currentTimeMillis())
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "StableAction_$name")
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/StableAction")
                }
            }

            val mediaStoreOutputOptions = MediaStoreOutputOptions
                .Builder(context.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setContentValues(contentValues)
                .build()

            recording = videoCapture?.output
                ?.prepareRecording(context, mediaStoreOutputOptions)
                ?.apply { withAudioEnabled() }
                ?.start(ContextCompat.getMainExecutor(context)) { recordEvent ->
                    when (recordEvent) {
                        is VideoRecordEvent.Start -> {
                            isRecording = true
                            onRecordingStateChanged?.invoke(true)
                        }
                        is VideoRecordEvent.Finalize -> {
                            if (!recordEvent.hasError()) {
                                lastVideoUri = recordEvent.outputResults.outputUri
                                onLastVideoChanged?.invoke(lastVideoUri)
                            } else {
                                Log.e("CameraManager", "Recording error: ${recordEvent.error}")
                            }
                            isRecording = false
                            onRecordingStateChanged?.invoke(false)
                        }
                    }
                }
        }
    }

    fun setActionMode(enabled: Boolean, previewView: PreviewView) {
        actionModeEnabled = enabled
        bindCameraUseCases(previewView)
    }

    fun focusAt(x: Float, y: Float, meteringPointFactory: MeteringPointFactory) {
        // Focus handled by CameraX automatically via PreviewView tap
    }

    fun shutdown() {
        cameraExecutor.shutdown()
        if (isRecording) {
            recording?.stop()
        }
    }
}
