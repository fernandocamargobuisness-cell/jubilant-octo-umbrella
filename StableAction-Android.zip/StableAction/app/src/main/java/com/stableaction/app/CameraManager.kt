package com.stableaction.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.*
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.sin

class CameraManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {

    @Volatile var isRecording = false
        private set
    @Volatile var actionModeEnabled = false
    @Volatile var lastVideoUri: Uri? = null

    var onRecordingStateChanged: ((Boolean) -> Unit)? = null
    var onLastVideoChanged: ((Uri?) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var onFrameProcessed: ((Bitmap) -> Unit)? = null
    var motionSnapshotProvider: () -> Triple<Double, Double, Double> = { Triple(0.0, 0.0, 0.0) }

    private var cameraProvider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val cropFraction = 3.0 / 5.0 * 0.90
    private val cropAspectH = 4.0
    private val cropAspectW = 3.0
    private var smoothedRoll = 0.0
    private var smoothedNormX = 0.0
    private var smoothedNormY = 0.0
    private val rollAlpha = 0.25
    private val translationAlpha = 0.10

    fun startCamera(previewView: PreviewView) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            cameraProvider = future.get()
            bindCameraUseCases(previewView)
        }, ContextCompat.getMainExecutor(context))
    }

    private fun bindCameraUseCases(previewView: PreviewView) {
        val provider = cameraProvider ?: return

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.HD))
            .build()
        videoCapture = VideoCapture.withOutput(recorder)

        val imageAnalysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
            .also { analysis ->
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    if (actionModeEnabled) processFrame(imageProxy)
                    else imageProxy.close()
                }
            }

        try {
            provider.unbindAll()
            provider.bindToLifecycle(
                lifecycleOwner,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                videoCapture,
                imageAnalysis
            )
        } catch (exc: Exception) {
            Log.e("CameraManager", "Binding failed", exc)
            onError?.invoke("Camera error: ${exc.message}")
        }
    }

    private fun processFrame(imageProxy: ImageProxy) {
        try {
            val (snapRoll, snapOffsetX, snapOffsetY) = motionSnapshotProvider()
            smoothedRoll += rollAlpha * (snapRoll - smoothedRoll)
            smoothedNormX += translationAlpha * (snapOffsetX - smoothedNormX)
            smoothedNormY += translationAlpha * (snapOffsetY - smoothedNormY)

            val plane = imageProxy.planes[0]
            val buffer = plane.buffer
            val rowPadding = plane.rowStride - plane.pixelStride * imageProxy.width

            val bitmap = Bitmap.createBitmap(
                imageProxy.width + rowPadding / plane.pixelStride,
                imageProxy.height, Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val rotMatrix = Matrix().apply { postRotate(90f) }
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, rotMatrix, true)
            bitmap.recycle()

            val pW = rotated.width.toFloat()
            val pH = rotated.height.toFloat()
            val angleDeg = Math.toDegrees(-smoothedRoll).toFloat()
            val stabilMatrix = Matrix().apply { postRotate(angleDeg, pW / 2, pH / 2) }
            val stabilized = Bitmap.createBitmap(rotated, 0, 0, rotated.width, rotated.height, stabilMatrix, true)
            rotated.recycle()

            val shorter = minOf(pW, pH)
            val cropW = (shorter * cropFraction).toFloat()
            val cropH = (cropW * (cropAspectH / cropAspectW)).toFloat()
            val marginX = maxOf(0f, (stabilized.width - cropW) / 2)
            val marginY = maxOf(0f, (stabilized.height - cropH) / 2)

            val angleRad = (-smoothedRoll).toFloat()
            val cosA = cos(angleRad.toDouble()).toFloat()
            val sinA = sin(angleRad.toDouble()).toFloat()
            val shiftX = (smoothedNormX * cosA - smoothedNormY * sinA).toFloat() * marginX * 0.9f
            val shiftY = (smoothedNormX * sinA + smoothedNormY * cosA).toFloat() * marginY * 0.9f

            val cropX = ((stabilized.width - cropW) / 2 + shiftX).coerceIn(0f, maxOf(0f, stabilized.width - cropW))
            val cropY = ((stabilized.height - cropH) / 2 + shiftY).coerceIn(0f, maxOf(0f, stabilized.height - cropH))
            val cropWInt = cropW.toInt().and(-2)
            val cropHInt = cropH.toInt().and(-2)

            if (cropX.toInt() + cropWInt <= stabilized.width && cropY.toInt() + cropHInt <= stabilized.height && cropWInt > 0 && cropHInt > 0) {
                val cropped = Bitmap.createBitmap(stabilized, cropX.toInt(), cropY.toInt(), cropWInt, cropHInt)
                stabilized.recycle()
                onFrameProcessed?.invoke(cropped)
            } else {
                stabilized.recycle()
            }
        } catch (e: Exception) {
            Log.e("CameraManager", "Frame error", e)
        } finally {
            imageProxy.close()
        }
    }

    @SuppressLint("MissingPermission")
    fun toggleRecording() {
        if (isRecording) {
            recording?.stop()
            recording = null
        } else {
            val name = SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-SSS", Locale.US).format(System.currentTimeMillis())
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "StableAction_$name")
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P)
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/StableAction")
            }
            val outputOptions = MediaStoreOutputOptions
                .Builder(context.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setContentValues(contentValues).build()

            recording = videoCapture?.output
                ?.prepareRecording(context, outputOptions)
                ?.apply { withAudioEnabled() }
                ?.start(ContextCompat.getMainExecutor(context)) { event ->
                    when (event) {
                        is VideoRecordEvent.Start -> { isRecording = true; onRecordingStateChanged?.invoke(true) }
                        is VideoRecordEvent.Finalize -> {
                            if (!event.hasError()) { lastVideoUri = event.outputResults.outputUri; onLastVideoChanged?.invoke(lastVideoUri) }
                            isRecording = false; onRecordingStateChanged?.invoke(false)
                        }
                    }
                }
        }
    }

    fun setActionMode(enabled: Boolean, previewView: PreviewView) {
        actionModeEnabled = enabled
        bindCameraUseCases(previewView)
    }

    fun shutdown() {
        cameraExecutor.shutdown()
        if (isRecording) recording?.stop()
    }
}
