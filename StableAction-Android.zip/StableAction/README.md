# Stable Action - Android

Port of the Stable Action iOS app. Camera app with horizon-lock stabilization, action mode, and smooth gimbal-like movement.

## Features
- ✅ Normal mode: standard camera preview
- ✅ Action mode: software horizon stabilization (roll + translation compensation)
- ✅ Animated Normal/Action toggle
- ✅ Tap-to-focus with animated indicator
- ✅ Record video with audio
- ✅ Video thumbnail preview
- ✅ REC blinking indicator
- ✅ Same motion tuning constants as iOS (velocityDecay, positionDecay, sensitivity)

## How to build the APK (from your phone)

### Option 1: GitHub Actions (easiest, 100% free)
1. Create a new **public** repository on GitHub
2. Upload all these files (maintain the folder structure)
3. Go to **Actions** tab → the workflow runs automatically
4. When it finishes (~5 min), click the run → **Artifacts** → download `StableAction-debug`
5. Install the APK on your Android phone

### Option 2: Android Studio (on a PC/Mac)
1. Open this folder in Android Studio
2. Click **Build → Build APK(s)**
3. APK will be at `app/build/outputs/apk/debug/app-debug.apk`

## Requirements
- Android 8.0+ (API 26)
- Camera + Microphone permissions
- Accelerometer + Gyroscope sensors
